import axios from "axios";

// fetch once at the top
const res = await axios.get("https://dummyjson.com/users");
const users = res.data.users;

function Home() {
  return (
    <div>
      {users.map((u) => (
        <div key={u.id}>{u.firstName} {u.lastName}</div>
      ))}
          
    </div>
  );
}

export default Home;
