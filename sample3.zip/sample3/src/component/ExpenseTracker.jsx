// import { useContext } from "react";
// import { ExpenseContext } from "../App";
// function ExpenseTracker(){
//     const{product}=useContext(ExpenseContext);
//    return(
//     <>
//     <h1>Expense Tracker</h1>
//     </>
//    )
// }
// export  default ExpenseTracker;